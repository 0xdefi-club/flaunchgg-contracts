export const BlankABI = [
  {
    "name": "execute",
    "type": "function",
    "inputs": [],
    "outputs": [],
    "stateMutability": "nonpayable"
  }
] as const;

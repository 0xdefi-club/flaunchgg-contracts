export const BurnTokensABI = [
  {
    "name": "execute",
    "type": "function",
    "inputs": [],
    "outputs": [],
    "stateMutability": "nonpayable"
  }
] as const;

export const DistributeABI = [
  {
    "name": "execute",
    "type": "function",
    "inputs": [],
    "outputs": [],
    "stateMutability": "nonpayable"
  }
] as const;

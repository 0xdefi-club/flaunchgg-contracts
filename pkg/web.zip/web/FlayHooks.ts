export const FlayHooksABI = [] as const;

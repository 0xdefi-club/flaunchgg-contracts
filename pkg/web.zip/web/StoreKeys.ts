export const StoreKeysABI = [] as const;
